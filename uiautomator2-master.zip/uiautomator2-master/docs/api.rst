API
----------

.. autoclass:: uiautomator2.Device
   :members:

.. autoclass:: uiautomator2.Session
   :members:

.. autoclass:: uiautomator2.xpath.XPath
   :members:
